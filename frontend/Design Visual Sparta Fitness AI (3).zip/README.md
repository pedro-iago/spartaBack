
  # Design Visual Sparta Fitness AI

  This is a code bundle for Design Visual Sparta Fitness AI. The original project is available at https://www.figma.com/design/LdtV5ll8MhHHpbBBZd3HE3/Design-Visual-Sparta-Fitness-AI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  