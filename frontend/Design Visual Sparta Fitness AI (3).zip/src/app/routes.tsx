import { createBrowserRouter } from "react-router";
import { StudentDashboard } from "@/app/components/StudentDashboard";
import { TrainerDashboard } from "@/app/components/TrainerDashboard";
import { AdminDashboard } from "@/app/components/AdminDashboard";
import { Login } from "@/app/components/Login";
import { WorkoutEditor } from "@/app/components/WorkoutEditor";
import { WorkoutExecution } from "@/app/components/WorkoutExecution";
import { StudentWorkouts } from "@/app/components/StudentWorkouts";
import { StudentProfile } from "@/app/components/StudentProfile";
import { TrainerStudents } from "@/app/components/TrainerStudents";
import { AdminUsers } from "@/app/components/AdminUsers";
import { AdminReports } from "@/app/components/AdminReports";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/student",
    Component: StudentDashboard,
  },
  {
    path: "/student/workouts",
    Component: StudentWorkouts,
  },
  {
    path: "/student/profile",
    Component: StudentProfile,
  },
  {
    path: "/student/workout",
    Component: WorkoutExecution,
  },
  {
    path: "/trainer",
    Component: TrainerDashboard,
  },
  {
    path: "/trainer/students",
    Component: TrainerStudents,
  },
  {
    path: "/trainer/edit-workout",
    Component: WorkoutEditor,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
  {
    path: "/admin/users",
    Component: AdminUsers,
  },
  {
    path: "/admin/reports",
    Component: AdminReports,
  },
]);