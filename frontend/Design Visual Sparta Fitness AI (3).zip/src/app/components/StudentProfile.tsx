import { useState } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import { Separator } from "@/app/components/ui/separator";
import {
  User,
  Mail,
  Phone,
  Calendar,
  Target,
  TrendingUp,
  Award,
  Flame,
  Dumbbell,
  Edit,
  Camera,
  Home,
  ChefHat,
  ArrowLeft,
} from "lucide-react";
import { useNavigate } from "react-router";

export function StudentProfile() {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);

  const profileData = {
    name: "Carlos Silva",
    email: "carlos.silva@email.com",
    phone: "(11) 98765-4321",
    joinedDate: "Janeiro 2026",
    goal: "Hipertrofia Muscular",
    currentWeight: 78,
    goalWeight: 85,
    height: 175,
  };

  const stats = {
    currentStreak: 7,
    totalWorkouts: 42,
    totalWeight: 12600, // kg lifted total
    achievements: 8,
  };

  const achievements = [
    { id: 1, name: "Primeira Semana", icon: "🏅", unlocked: true },
    { id: 2, name: "10 Treinos", icon: "💪", unlocked: true },
    { id: 3, name: "Sequência de 7 dias", icon: "🔥", unlocked: true },
    { id: 4, name: "50 Treinos", icon: "⭐", unlocked: false },
    { id: 5, name: "Mestre do Treino", icon: "👑", unlocked: false },
  ];

  const weeklyActivity = [
    { day: "Seg", completed: true },
    { day: "Ter", completed: true },
    { day: "Qua", completed: true },
    { day: "Qui", completed: true },
    { day: "Sex", completed: true },
    { day: "Sáb", completed: true },
    { day: "Dom", completed: true },
  ];

  const weightProgress = ((profileData.currentWeight - 70) / (profileData.goalWeight - 70)) * 100;

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-card via-card to-primary/5 border-b border-border p-6">
        <Button
          variant="ghost"
          size="icon"
          className="mb-4"
          onClick={() => navigate("/student")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <div className="flex items-start gap-4">
          {/* Avatar */}
          <div className="relative">
            <div className="bg-gradient-to-br from-primary to-primary/60 rounded-full w-24 h-24 flex items-center justify-center text-3xl font-bold text-primary-foreground">
              CS
            </div>
            <Button
              size="icon"
              className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Camera className="h-4 w-4" />
            </Button>
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h1 className="text-2xl">{profileData.name}</h1>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(!isEditing)}
              >
                <Edit className="mr-2 h-4 w-4" />
                {isEditing ? "Cancelar" : "Editar"}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Membro desde {profileData.joinedDate}
            </p>
            <Badge className="bg-primary/20 text-primary border-primary/30">
              <Target className="mr-1 h-3 w-3" />
              {profileData.goal}
            </Badge>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="bg-gradient-to-br from-primary/20 to-transparent border-primary/30 p-4">
            <Flame className="h-6 w-6 text-primary mb-2" />
            <p className="text-2xl font-bold">{stats.currentStreak}</p>
            <p className="text-xs text-muted-foreground">Dias seguidos</p>
          </Card>

          <Card className="bg-card border-border p-4">
            <Dumbbell className="h-6 w-6 text-primary mb-2" />
            <p className="text-2xl font-bold">{stats.totalWorkouts}</p>
            <p className="text-xs text-muted-foreground">Treinos</p>
          </Card>

          <Card className="bg-card border-border p-4">
            <TrendingUp className="h-6 w-6 text-primary mb-2" />
            <p className="text-2xl font-bold">{(stats.totalWeight / 1000).toFixed(1)}t</p>
            <p className="text-xs text-muted-foreground">Peso levantado</p>
          </Card>

          <Card className="bg-card border-border p-4">
            <Award className="h-6 w-6 text-primary mb-2" />
            <p className="text-2xl font-bold">{stats.achievements}</p>
            <p className="text-xs text-muted-foreground">Conquistas</p>
          </Card>
        </div>

        {/* Weekly Activity */}
        <Card className="bg-card border-border p-6">
          <h3 className="text-lg mb-4">Atividade Semanal</h3>
          <div className="flex justify-between gap-2">
            {weeklyActivity.map((day, index) => (
              <div key={index} className="flex flex-col items-center gap-2">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    day.completed
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {day.completed ? "✓" : "·"}
                </div>
                <span className="text-xs text-muted-foreground">{day.day}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Personal Info */}
        <Card className="bg-card border-border p-6">
          <h3 className="text-lg mb-4">Informações Pessoais</h3>
          <div className="space-y-4">
            <div>
              <Label className="text-muted-foreground text-sm">Nome Completo</Label>
              {isEditing ? (
                <Input value={profileData.name} className="mt-1 bg-muted border-border" />
              ) : (
                <p className="mt-1 flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  {profileData.name}
                </p>
              )}
            </div>

            <div>
              <Label className="text-muted-foreground text-sm">Email</Label>
              {isEditing ? (
                <Input value={profileData.email} className="mt-1 bg-muted border-border" />
              ) : (
                <p className="mt-1 flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  {profileData.email}
                </p>
              )}
            </div>

            <div>
              <Label className="text-muted-foreground text-sm">Telefone</Label>
              {isEditing ? (
                <Input value={profileData.phone} className="mt-1 bg-muted border-border" />
              ) : (
                <p className="mt-1 flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  {profileData.phone}
                </p>
              )}
            </div>
          </div>

          {isEditing && (
            <Button className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground">
              Salvar Alterações
            </Button>
          )}
        </Card>

        {/* Physical Stats */}
        <Card className="bg-card border-border p-6">
          <h3 className="text-lg mb-4">Estatísticas Físicas</h3>
          
          <div className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <Label className="text-muted-foreground text-sm">Peso</Label>
                <span className="text-sm font-medium">
                  {profileData.currentWeight}kg / {profileData.goalWeight}kg
                </span>
              </div>
              <Progress value={weightProgress} className="h-2 bg-muted" />
              <p className="text-xs text-muted-foreground mt-1">
                Faltam {profileData.goalWeight - profileData.currentWeight}kg para sua meta
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground text-sm">Altura</Label>
                <p className="text-2xl font-bold">{profileData.height}cm</p>
              </div>
              <div>
                <Label className="text-muted-foreground text-sm">IMC</Label>
                <p className="text-2xl font-bold">
                  {(profileData.currentWeight / ((profileData.height / 100) ** 2)).toFixed(1)}
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Achievements */}
        <Card className="bg-card border-border p-6">
          <h3 className="text-lg mb-4">Conquistas</h3>
          <div className="space-y-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`flex items-center gap-3 p-3 rounded-lg border ${
                  achievement.unlocked
                    ? "bg-primary/10 border-primary/30"
                    : "bg-muted/50 border-border opacity-50"
                }`}
              >
                <div className="text-3xl">{achievement.icon}</div>
                <div className="flex-1">
                  <p className="font-medium">{achievement.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {achievement.unlocked ? "Desbloqueado" : "Bloqueado"}
                  </p>
                </div>
                {achievement.unlocked && (
                  <Award className="h-5 w-5 text-primary" />
                )}
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="flex justify-around items-center h-16 max-w-md mx-auto px-4">
          <Button
            variant="ghost"
            size="icon"
            className="flex-col h-auto gap-1"
            onClick={() => navigate("/student")}
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">Início</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="flex-col h-auto gap-1"
            onClick={() => navigate("/student/workouts")}
          >
            <Dumbbell className="h-5 w-5" />
            <span className="text-xs">Treinos</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex-col h-auto gap-1">
            <ChefHat className="h-5 w-5" />
            <span className="text-xs">Dieta</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex-col h-auto gap-1 text-primary">
            <User className="h-5 w-5" />
            <span className="text-xs">Perfil</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
