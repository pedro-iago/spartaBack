import { useState } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Badge } from "@/app/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Save,
  ArrowLeft,
  Sparkles,
} from "lucide-react";
import { useNavigate } from "react-router";

interface Set {
  id: string;
  type: "warmup" | "normal";
  kg: string;
  reps: string;
}

interface Exercise {
  id: string;
  name: string;
  category: string;
  sets: Set[];
  isExpanded: boolean;
}

export function WorkoutEditor() {
  const navigate = useNavigate();
  const [workoutName, setWorkoutName] = useState("Hypertrophy Push A");
  const [exercises, setExercises] = useState<Exercise[]>([
    {
      id: "1",
      name: "Supino Reto",
      category: "Peito",
      isExpanded: true,
      sets: [
        { id: "s1", type: "warmup", kg: "40", reps: "12" },
        { id: "s2", type: "warmup", kg: "60", reps: "10" },
        { id: "s3", type: "normal", kg: "80", reps: "8" },
        { id: "s4", type: "normal", kg: "80", reps: "8" },
        { id: "s5", type: "normal", kg: "80", reps: "8" },
      ],
    },
    {
      id: "2",
      name: "Desenvolvimento com Halteres",
      category: "Ombros",
      isExpanded: false,
      sets: [
        { id: "s1", type: "warmup", kg: "12", reps: "15" },
        { id: "s2", type: "normal", kg: "20", reps: "10" },
        { id: "s3", type: "normal", kg: "20", reps: "10" },
        { id: "s4", type: "normal", kg: "20", reps: "10" },
      ],
    },
    {
      id: "3",
      name: "Tríceps na Polia",
      category: "Tríceps",
      isExpanded: false,
      sets: [
        { id: "s1", type: "normal", kg: "30", reps: "12" },
        { id: "s2", type: "normal", kg: "30", reps: "12" },
        { id: "s3", type: "normal", kg: "30", reps: "12" },
      ],
    },
  ]);

  const toggleExercise = (exerciseId: string) => {
    setExercises(prev => prev.map(ex => 
      ex.id === exerciseId ? { ...ex, isExpanded: !ex.isExpanded } : ex
    ));
  };

  const addSet = (exerciseId: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id === exerciseId) {
        const newSet: Set = {
          id: `s${ex.sets.length + 1}`,
          type: "normal",
          kg: "",
          reps: "",
        };
        return { ...ex, sets: [...ex.sets, newSet] };
      }
      return ex;
    }));
  };

  const deleteSet = (exerciseId: string, setId: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id === exerciseId) {
        return { ...ex, sets: ex.sets.filter(s => s.id !== setId) };
      }
      return ex;
    }));
  };

  const updateSet = (exerciseId: string, setId: string, field: keyof Set, value: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.map(s => 
            s.id === setId ? { ...s, [field]: value } : s
          ),
        };
      }
      return ex;
    }));
  };

  return (
    <div className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="bg-card border-b border-border p-4 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/trainer")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Badge className="bg-primary/20 text-primary border-primary/30">
            <Sparkles className="mr-1 h-3 w-3" />
            Gerado por IA
          </Badge>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Save className="mr-2 h-4 w-4" />
            Salvar
          </Button>
        </div>
        <Input
          value={workoutName}
          onChange={(e) => setWorkoutName(e.target.value)}
          className="text-xl font-bold bg-muted border-border h-12"
        />
      </div>

      {/* Student Info */}
      <div className="p-4 bg-card/50 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="bg-primary/20 rounded-full w-10 h-10 flex items-center justify-center">
            <span className="font-bold text-primary">CS</span>
          </div>
          <div>
            <p className="font-semibold">Carlos Silva</p>
            <p className="text-sm text-muted-foreground">Objetivo: Hipertrofia</p>
          </div>
        </div>
      </div>

      {/* Exercises List */}
      <div className="p-4 space-y-3">
        {exercises.map((exercise, exerciseIndex) => (
          <Card key={exercise.id} className="bg-card border-border overflow-hidden">
            {/* Exercise Header */}
            <div
              className="p-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => toggleExercise(exercise.id)}
            >
              <div className="flex items-center gap-3">
                <div className="bg-primary/10 text-primary rounded-full w-8 h-8 flex items-center justify-center font-bold">
                  {exerciseIndex + 1}
                </div>
                <div>
                  <p className="font-semibold">{exercise.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {exercise.category} • {exercise.sets.length} séries
                  </p>
                </div>
              </div>
              {exercise.isExpanded ? (
                <ChevronUp className="h-5 w-5 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              )}
            </div>

            {/* Sets Table */}
            {exercise.isExpanded && (
              <div className="border-t border-border">
                {/* Table Header */}
                <div className="grid grid-cols-[100px_1fr_1fr_50px] gap-2 p-3 bg-muted/30 text-sm font-medium text-muted-foreground">
                  <div>Tipo</div>
                  <div>Kg</div>
                  <div>Reps</div>
                  <div></div>
                </div>

                {/* Table Rows */}
                <div className="divide-y divide-border">
                  {exercise.sets.map((set, setIndex) => (
                    <div
                      key={set.id}
                      className="grid grid-cols-[100px_1fr_1fr_50px] gap-2 p-3 items-center hover:bg-muted/30 transition-colors group"
                    >
                      {/* Set Type */}
                      <div>
                        <Select
                          value={set.type}
                          onValueChange={(value) => 
                            updateSet(exercise.id, set.id, "type", value)
                          }
                        >
                          <SelectTrigger className="h-8 border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="warmup">
                              <Badge variant="secondary" className="text-xs">
                                Aquec.
                              </Badge>
                            </SelectItem>
                            <SelectItem value="normal">
                              <Badge className="bg-primary/20 text-primary text-xs">
                                Normal
                              </Badge>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Weight Input */}
                      <Input
                        type="number"
                        value={set.kg}
                        onChange={(e) => 
                          updateSet(exercise.id, set.id, "kg", e.target.value)
                        }
                        placeholder="kg"
                        className="h-8 bg-background border-border"
                      />

                      {/* Reps Input */}
                      <Input
                        type="number"
                        value={set.reps}
                        onChange={(e) => 
                          updateSet(exercise.id, set.id, "reps", e.target.value)
                        }
                        placeholder="reps"
                        className="h-8 bg-background border-border"
                      />

                      {/* Delete Button */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => deleteSet(exercise.id, set.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                {/* Add Set Button */}
                <div className="p-3 border-t border-border bg-muted/20">
                  <Button
                    variant="outline"
                    className="w-full border-dashed border-primary/30 hover:bg-primary/10 text-primary"
                    onClick={() => addSet(exercise.id)}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Série
                  </Button>
                </div>
              </div>
            )}
          </Card>
        ))}

        {/* Add Exercise Button */}
        <Button
          variant="outline"
          className="w-full h-12 border-dashed border-border hover:bg-muted"
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Exercício
        </Button>
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 space-y-2">
        <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12">
          <Save className="mr-2 h-5 w-5" />
          APROVAR E ATIVAR TREINO
        </Button>
        <Button variant="outline" className="w-full h-10 border-border">
          Pré-visualizar como Aluno
        </Button>
      </div>
    </div>
  );
}
