import { useState } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Badge } from "@/app/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  Users,
  Search,
  UserPlus,
  Dumbbell,
  Calendar,
  TrendingUp,
  MessageSquare,
  MoreVertical,
  FileText,
  Sparkles,
  LogOut,
  Filter,
  Mail,
  Phone,
} from "lucide-react";
import { useNavigate } from "react-router";

interface Student {
  id: string;
  name: string;
  avatar: string;
  email: string;
  phone: string;
  goal: string;
  joinedDate: string;
  lastWorkout: string;
  activeWorkouts: number;
  completionRate: number;
  status: "active" | "inactive";
}

export function TrainerStudents() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const students: Student[] = [
    {
      id: "1",
      name: "Carlos Silva",
      avatar: "CS",
      email: "carlos@email.com",
      phone: "(11) 98765-4321",
      goal: "Hipertrofia",
      joinedDate: "Jan 2026",
      lastWorkout: "Hoje",
      activeWorkouts: 3,
      completionRate: 92,
      status: "active",
    },
    {
      id: "2",
      name: "Ana Santos",
      avatar: "AS",
      email: "ana@email.com",
      phone: "(11) 98765-4322",
      goal: "Emagrecimento",
      joinedDate: "Fev 2026",
      lastWorkout: "Ontem",
      activeWorkouts: 4,
      completionRate: 88,
      status: "active",
    },
    {
      id: "3",
      name: "João Pedro",
      avatar: "JP",
      email: "joao@email.com",
      phone: "(11) 98765-4323",
      goal: "Força",
      joinedDate: "Jan 2026",
      lastWorkout: "2 dias atrás",
      activeWorkouts: 3,
      completionRate: 95,
      status: "active",
    },
    {
      id: "4",
      name: "Marina Costa",
      avatar: "MC",
      email: "marina@email.com",
      phone: "(11) 98765-4324",
      goal: "Condicionamento",
      joinedDate: "Dez 2025",
      lastWorkout: "5 dias atrás",
      activeWorkouts: 2,
      completionRate: 65,
      status: "inactive",
    },
    {
      id: "5",
      name: "Rafael Oliveira",
      avatar: "RO",
      email: "rafael@email.com",
      phone: "(11) 98765-4325",
      goal: "Hipertrofia",
      joinedDate: "Fev 2026",
      lastWorkout: "Hoje",
      activeWorkouts: 3,
      completionRate: 90,
      status: "active",
    },
    {
      id: "6",
      name: "Julia Almeida",
      avatar: "JA",
      email: "julia@email.com",
      phone: "(11) 98765-4326",
      goal: "Emagrecimento",
      joinedDate: "Jan 2026",
      lastWorkout: "Ontem",
      activeWorkouts: 4,
      completionRate: 85,
      status: "active",
    },
  ];

  const filteredStudents = students.filter((student) => {
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || student.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: students.length,
    active: students.filter((s) => s.status === "active").length,
    inactive: students.filter((s) => s.status === "inactive").length,
    avgCompletion: Math.round(
      students.reduce((sum, s) => sum + s.completionRate, 0) / students.length
    ),
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-sidebar border-r border-sidebar-border p-6 hidden lg:block">
        <div className="mb-8">
          <h1 className="text-2xl mb-1 text-primary">SPARTA AI</h1>
          <p className="text-sm text-muted-foreground">Personal Trainer</p>
        </div>

        <nav className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate("/trainer")}
          >
            <FileText className="mr-3 h-5 w-5" />
            Revisões
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start bg-primary/10 text-primary hover:bg-primary/20"
          >
            <Users className="mr-3 h-5 w-5" />
            Meus Alunos
          </Button>
          <Button variant="ghost" className="w-full justify-start">
            <Sparkles className="mr-3 h-5 w-5" />
            IA Assistente
          </Button>
        </nav>

        <div className="absolute bottom-6 left-6 right-6">
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground"
            onClick={() => navigate("/")}
          >
            <LogOut className="mr-3 h-5 w-5" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">
        {/* Header */}
        <div className="bg-card border-b border-border p-6">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl mb-2">Meus Alunos</h1>
            <p className="text-muted-foreground">Gerencie e acompanhe seus alunos</p>
          </div>
        </div>

        <div className="p-6 max-w-7xl mx-auto space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-primary/20 to-transparent border-primary/30 p-6">
              <Users className="h-6 w-6 text-primary mb-2" />
              <p className="text-3xl font-bold">{stats.total}</p>
              <p className="text-sm text-muted-foreground">Total de Alunos</p>
            </Card>

            <Card className="bg-card border-border p-6">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="h-6 w-6 text-success" />
                <Badge className="bg-success/20 text-success border-success/30">Ativos</Badge>
              </div>
              <p className="text-3xl font-bold">{stats.active}</p>
              <p className="text-sm text-muted-foreground">Alunos ativos</p>
            </Card>

            <Card className="bg-card border-border p-6">
              <div className="flex items-center justify-between mb-2">
                <Calendar className="h-6 w-6 text-muted-foreground" />
                <Badge variant="secondary">Inativos</Badge>
              </div>
              <p className="text-3xl font-bold">{stats.inactive}</p>
              <p className="text-sm text-muted-foreground">Precisam atenção</p>
            </Card>

            <Card className="bg-card border-border p-6">
              <Dumbbell className="h-6 w-6 text-primary mb-2" />
              <p className="text-3xl font-bold">{stats.avgCompletion}%</p>
              <p className="text-sm text-muted-foreground">Taxa de conclusão</p>
            </Card>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar aluno..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-muted border-border"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px] bg-muted border-border">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Ativos</SelectItem>
                <SelectItem value="inactive">Inativos</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <UserPlus className="mr-2 h-4 w-4" />
              Novo Aluno
            </Button>
          </div>

          {/* Students Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStudents.map((student) => (
              <Card
                key={student.id}
                className="bg-card border-border hover:border-primary/50 transition-colors"
              >
                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/20 rounded-full w-12 h-12 flex items-center justify-center">
                        <span className="font-bold text-primary">{student.avatar}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold">{student.name}</h3>
                        <p className="text-xs text-muted-foreground">
                          Desde {student.joinedDate}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Status Badge */}
                  <div className="mb-4">
                    {student.status === "active" ? (
                      <Badge className="bg-success/20 text-success border-success/30">
                        Ativo
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-muted text-muted-foreground">
                        Inativo
                      </Badge>
                    )}
                    <Badge variant="outline" className="ml-2 border-primary/30">
                      {student.goal}
                    </Badge>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-2 mb-4 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-3 w-3" />
                      <span className="truncate">{student.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3 w-3" />
                      <span>{student.phone}</span>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="space-y-3 mb-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Taxa de conclusão</span>
                        <span className="font-medium">{student.completionRate}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary"
                          style={{ width: `${student.completionRate}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Treinos ativos</span>
                      <span className="font-medium">{student.activeWorkouts}</span>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Último treino</span>
                      <span className="font-medium">{student.lastWorkout}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 border-primary/30 hover:bg-primary/10"
                    >
                      <Dumbbell className="mr-2 h-3 w-3" />
                      Treinos
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 border-border hover:bg-muted"
                    >
                      <MessageSquare className="mr-2 h-3 w-3" />
                      Chat
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Empty State */}
          {filteredStudents.length === 0 && (
            <Card className="bg-card border-border p-12 text-center">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Nenhum aluno encontrado</h3>
              <p className="text-muted-foreground mb-6">
                Tente ajustar os filtros ou adicione um novo aluno
              </p>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <UserPlus className="mr-2 h-4 w-4" />
                Adicionar Aluno
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
