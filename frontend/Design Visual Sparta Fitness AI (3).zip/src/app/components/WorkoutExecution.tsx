import { useState, useEffect } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import {
  Check,
  X,
  Timer,
  Pause,
  Play,
  ArrowLeft,
  Trophy,
  Clock,
} from "lucide-react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";

interface SetExecution {
  id: string;
  type: "warmup" | "normal";
  plannedKg: number;
  plannedReps: number;
  actualKg: string;
  actualReps: string;
  completed: boolean;
  lastKg?: number;
  lastReps?: number;
}

interface ExerciseExecution {
  id: string;
  name: string;
  category: string;
  sets: SetExecution[];
}

export function WorkoutExecution() {
  const navigate = useNavigate();
  const [workoutTime, setWorkoutTime] = useState(0);
  const [isWorkoutActive, setIsWorkoutActive] = useState(true);
  const [restTimer, setRestTimer] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [activeRestSetId, setActiveRestSetId] = useState<string | null>(null);

  const [exercises, setExercises] = useState<ExerciseExecution[]>([
    {
      id: "1",
      name: "Supino Reto",
      category: "Peito",
      sets: [
        { id: "s1", type: "warmup", plannedKg: 40, plannedReps: 12, actualKg: "", actualReps: "", completed: false, lastKg: 40, lastReps: 12 },
        { id: "s2", type: "warmup", plannedKg: 60, plannedReps: 10, actualKg: "", actualReps: "", completed: false, lastKg: 60, lastReps: 10 },
        { id: "s3", type: "normal", plannedKg: 80, plannedReps: 8, actualKg: "", actualReps: "", completed: false, lastKg: 80, lastReps: 9 },
        { id: "s4", type: "normal", plannedKg: 80, plannedReps: 8, actualKg: "", actualReps: "", completed: false, lastKg: 80, lastReps: 8 },
        { id: "s5", type: "normal", plannedKg: 80, plannedReps: 8, actualKg: "", actualReps: "", completed: false, lastKg: 80, lastReps: 7 },
      ],
    },
    {
      id: "2",
      name: "Desenvolvimento com Halteres",
      category: "Ombros",
      sets: [
        { id: "s1", type: "warmup", plannedKg: 12, plannedReps: 15, actualKg: "", actualReps: "", completed: false, lastKg: 12, lastReps: 15 },
        { id: "s2", type: "normal", plannedKg: 20, plannedReps: 10, actualKg: "", actualReps: "", completed: false, lastKg: 20, lastReps: 10 },
        { id: "s3", type: "normal", plannedKg: 20, plannedReps: 10, actualKg: "", actualReps: "", completed: false, lastKg: 20, lastReps: 11 },
        { id: "s4", type: "normal", plannedKg: 20, plannedReps: 10, actualKg: "", actualReps: "", completed: false, lastKg: 20, lastReps: 9 },
      ],
    },
    {
      id: "3",
      name: "Tríceps na Polia",
      category: "Tríceps",
      sets: [
        { id: "s1", type: "normal", plannedKg: 30, plannedReps: 12, actualKg: "", actualReps: "", completed: false, lastKg: 30, lastReps: 12 },
        { id: "s2", type: "normal", plannedKg: 30, plannedReps: 12, actualKg: "", actualReps: "", completed: false, lastKg: 30, lastReps: 12 },
        { id: "s3", type: "normal", plannedKg: 30, plannedReps: 12, actualKg: "", actualReps: "", completed: false, lastKg: 30, lastReps: 11 },
      ],
    },
  ]);

  // Workout timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isWorkoutActive) {
      interval = setInterval(() => {
        setWorkoutTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isWorkoutActive]);

  // Rest timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isResting && restTimer > 0) {
      interval = setInterval(() => {
        setRestTimer(prev => {
          if (prev <= 1) {
            setIsResting(false);
            setActiveRestSetId(null);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isResting, restTimer]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const completeSet = (exerciseId: string, setId: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.map(s => {
            if (s.id === setId) {
              // Auto-fill with planned values if empty
              const kg = s.actualKg || s.plannedKg.toString();
              const reps = s.actualReps || s.plannedReps.toString();
              return { ...s, actualKg: kg, actualReps: reps, completed: true };
            }
            return s;
          }),
        };
      }
      return ex;
    }));

    // Start rest timer
    setRestTimer(90); // 90 seconds rest
    setIsResting(true);
    setActiveRestSetId(setId);
  };

  const updateSetValue = (exerciseId: string, setId: string, field: "actualKg" | "actualReps", value: string) => {
    setExercises(prev => prev.map(ex => {
      if (ex.id === exerciseId) {
        return {
          ...ex,
          sets: ex.sets.map(s => 
            s.id === setId ? { ...s, [field]: value } : s
          ),
        };
      }
      return ex;
    }));
  };

  const totalSets = exercises.reduce((sum, ex) => sum + ex.sets.length, 0);
  const completedSets = exercises.reduce((sum, ex) => 
    sum + ex.sets.filter(s => s.completed).length, 0
  );
  const progress = (completedSets / totalSets) * 100;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Sticky Header */}
      <div className="sticky top-0 z-20 bg-card border-b border-border shadow-lg">
        <div className="flex items-center justify-between p-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/student")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-muted px-3 py-2 rounded-lg">
              <Clock className="h-4 w-4 text-primary" />
              <span className="font-mono font-bold">{formatTime(workoutTime)}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsWorkoutActive(!isWorkoutActive)}
            >
              {isWorkoutActive ? (
                <Pause className="h-5 w-5" />
              ) : (
                <Play className="h-5 w-5" />
              )}
            </Button>
          </div>

          <Button
            variant="outline"
            className="border-primary/30 text-primary hover:bg-primary/10"
            onClick={() => navigate("/student")}
          >
            Finalizar
          </Button>
        </div>

        {/* Progress Bar */}
        <div className="px-4 pb-3">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Progresso</span>
            <span className="font-medium">{completedSets}/{totalSets} séries</span>
          </div>
          <Progress value={progress} className="h-2 bg-muted" />
        </div>
      </div>

      {/* Exercises */}
      <div className="p-4 space-y-4">
        {exercises.map((exercise, exerciseIndex) => (
          <Card key={exercise.id} className="bg-card border-border overflow-hidden">
            {/* Exercise Header */}
            <div className="p-4 bg-gradient-to-r from-primary/10 to-transparent border-b border-border">
              <div className="flex items-center gap-3">
                <div className="bg-primary rounded-full w-8 h-8 flex items-center justify-center font-bold text-primary-foreground">
                  {exerciseIndex + 1}
                </div>
                <div>
                  <h3 className="font-semibold">{exercise.name}</h3>
                  <p className="text-sm text-muted-foreground">{exercise.category}</p>
                </div>
              </div>
            </div>

            {/* Sets */}
            <div className="divide-y divide-border">
              {exercise.sets.map((set, setIndex) => (
                <div
                  key={set.id}
                  className={`p-4 transition-colors ${
                    set.completed 
                      ? "bg-success/5 border-l-4 border-success" 
                      : "hover:bg-muted/30"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex-shrink-0 w-16 text-center">
                      <span className="text-sm font-medium text-muted-foreground">
                        Série {setIndex + 1}
                      </span>
                      {set.type === "warmup" && (
                        <Badge variant="secondary" className="text-xs mt-1">
                          Aquec.
                        </Badge>
                      )}
                    </div>

                    <div className="flex-1 grid grid-cols-2 gap-2">
                      {/* Weight Input */}
                      <div className="relative">
                        <Input
                          type="number"
                          value={set.actualKg}
                          onChange={(e) => 
                            updateSetValue(exercise.id, set.id, "actualKg", e.target.value)
                          }
                          placeholder={set.plannedKg.toString()}
                          disabled={set.completed}
                          className={`h-12 text-center font-semibold ${
                            set.completed ? "bg-muted" : "bg-background"
                          }`}
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                          kg
                        </span>
                        {set.lastKg && !set.completed && (
                          <p className="text-xs text-muted-foreground mt-1 text-center">
                            Último: {set.lastKg}kg
                          </p>
                        )}
                      </div>

                      {/* Reps Input */}
                      <div className="relative">
                        <Input
                          type="number"
                          value={set.actualReps}
                          onChange={(e) => 
                            updateSetValue(exercise.id, set.id, "actualReps", e.target.value)
                          }
                          placeholder={set.plannedReps.toString()}
                          disabled={set.completed}
                          className={`h-12 text-center font-semibold ${
                            set.completed ? "bg-muted" : "bg-background"
                          }`}
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                          reps
                        </span>
                        {set.lastReps && !set.completed && (
                          <p className="text-xs text-muted-foreground mt-1 text-center">
                            Último: {set.lastReps} reps
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Complete Button */}
                    <Button
                      size="icon"
                      className={`h-12 w-12 flex-shrink-0 ${
                        set.completed
                          ? "bg-success hover:bg-success/90 text-white"
                          : "bg-primary hover:bg-primary/90 text-primary-foreground"
                      }`}
                      onClick={() => completeSet(exercise.id, set.id)}
                      disabled={set.completed}
                    >
                      <Check className="h-6 w-6" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Floating Rest Timer */}
      <AnimatePresence>
        {isResting && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30"
          >
            <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-none shadow-2xl px-6 py-4">
              <div className="flex items-center gap-4">
                <Timer className="h-6 w-6 animate-pulse" />
                <div>
                  <p className="text-sm font-medium opacity-90">Descanso</p>
                  <p className="text-3xl font-mono font-bold">{formatTime(restTimer)}</p>
                </div>
                <Button
                  variant="secondary"
                  size="icon"
                  className="bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground"
                  onClick={() => {
                    setIsResting(false);
                    setRestTimer(0);
                    setActiveRestSetId(null);
                  }}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Finish Button */}
      {completedSets === totalSets && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="fixed bottom-6 left-4 right-4 z-30"
        >
          <Button
            className="w-full h-16 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-2xl"
            onClick={() => navigate("/student")}
          >
            <Trophy className="mr-2 h-6 w-6" />
            <span className="text-lg font-bold">TREINO CONCLUÍDO!</span>
          </Button>
        </motion.div>
      )}
    </div>
  );
}
