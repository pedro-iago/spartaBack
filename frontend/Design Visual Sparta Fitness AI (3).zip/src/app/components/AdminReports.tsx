import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  Users,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download,
  Calendar,
  LogOut,
  LayoutDashboard,
  Settings,
  BarChart3,
  Activity,
  Target,
} from "lucide-react";
import { useNavigate } from "react-router";

export function AdminReports() {
  const navigate = useNavigate();

  // Mock data for charts
  const revenueData = [
    { month: "Jul", revenue: 8000, expenses: 3000, profit: 5000 },
    { month: "Ago", revenue: 10000, expenses: 3500, profit: 6500 },
    { month: "Set", revenue: 12000, expenses: 4000, profit: 8000 },
    { month: "Out", revenue: 15000, expenses: 4500, profit: 10500 },
    { month: "Nov", revenue: 19000, expenses: 5000, profit: 14000 },
    { month: "Dez", revenue: 22000, expenses: 5500, profit: 16500 },
    { month: "Jan", revenue: 26000, expenses: 6000, profit: 20000 },
    { month: "Fev", revenue: 31000, expenses: 6500, profit: 24500 },
  ];

  const userGrowthData = [
    { month: "Jul", students: 25, trainers: 3 },
    { month: "Ago", students: 32, trainers: 4 },
    { month: "Set", students: 41, trainers: 5 },
    { month: "Out", students: 52, trainers: 6 },
    { month: "Nov", students: 63, trainers: 8 },
    { month: "Dez", students: 78, trainers: 10 },
    { month: "Jan", students: 95, trainers: 11 },
    { month: "Fev", students: 103, trainers: 12 },
  ];

  const subscriptionData = [
    { name: "Basic", value: 45, color: "#A1A1AA" },
    { name: "Premium", value: 38, color: "#FACC15" },
    { name: "Pro", value: 20, color: "#22C55E" },
  ];

  const workoutCompletionData = [
    { day: "Seg", completed: 85, planned: 100 },
    { day: "Ter", completed: 92, planned: 100 },
    { day: "Qua", completed: 88, planned: 100 },
    { day: "Qui", completed: 95, planned: 100 },
    { day: "Sex", completed: 90, planned: 100 },
    { day: "Sáb", completed: 78, planned: 100 },
    { day: "Dom", completed: 65, planned: 100 },
  ];

  const topMetrics = [
    {
      label: "Receita Total (MRR)",
      value: "R$ 31.000",
      change: "+24.5%",
      isPositive: true,
      icon: DollarSign,
      color: "text-primary",
      bgColor: "bg-primary/20",
    },
    {
      label: "Novos Usuários",
      value: "127",
      change: "+18.2%",
      isPositive: true,
      icon: Users,
      color: "text-success",
      bgColor: "bg-success/20",
    },
    {
      label: "Taxa de Retenção",
      value: "94.3%",
      change: "+2.1%",
      isPositive: true,
      icon: Target,
      color: "text-blue-500",
      bgColor: "bg-blue-500/20",
    },
    {
      label: "Taxa de Cancelamento",
      value: "5.7%",
      change: "-1.2%",
      isPositive: true,
      icon: TrendingDown,
      color: "text-success",
      bgColor: "bg-success/20",
    },
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border p-3 rounded-lg shadow-lg">
          <p className="text-sm font-medium mb-2">{payload[0].payload.month}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: R$ {entry.value.toLocaleString()}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-sidebar border-r border-sidebar-border p-6 hidden lg:block">
        <div className="mb-8">
          <h1 className="text-2xl mb-1 text-primary">SPARTA AI</h1>
          <p className="text-sm text-muted-foreground">Admin Panel</p>
        </div>

        <nav className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate("/admin")}
          >
            <LayoutDashboard className="mr-3 h-5 w-5" />
            Dashboard
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate("/admin/users")}
          >
            <Users className="mr-3 h-5 w-5" />
            Usuários
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start bg-primary/10 text-primary hover:bg-primary/20"
          >
            <BarChart3 className="mr-3 h-5 w-5" />
            Relatórios
          </Button>
          <Button variant="ghost" className="w-full justify-start">
            <Settings className="mr-3 h-5 w-5" />
            Configurações
          </Button>
        </nav>

        <div className="absolute bottom-6 left-6 right-6">
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground"
            onClick={() => navigate("/")}
          >
            <LogOut className="mr-3 h-5 w-5" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">
        {/* Header */}
        <div className="bg-card border-b border-border p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl mb-2">Relatórios e Analytics</h1>
                <p className="text-muted-foreground">
                  Análise detalhada do desempenho da plataforma
                </p>
              </div>
              <div className="flex gap-2">
                <Select defaultValue="30days">
                  <SelectTrigger className="w-[180px] bg-muted border-border">
                    <Calendar className="mr-2 h-4 w-4" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Últimos 7 dias</SelectItem>
                    <SelectItem value="30days">Últimos 30 dias</SelectItem>
                    <SelectItem value="90days">Últimos 90 dias</SelectItem>
                    <SelectItem value="year">Último ano</SelectItem>
                  </SelectContent>
                </Select>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar PDF
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 max-w-7xl mx-auto space-y-6">
          {/* Top Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {topMetrics.map((metric, index) => {
              const Icon = metric.icon;
              return (
                <Card key={index} className="bg-card border-border p-6">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm text-muted-foreground">{metric.label}</p>
                    <div className={`${metric.bgColor} p-2 rounded-full`}>
                      <Icon className={`h-4 w-4 ${metric.color}`} />
                    </div>
                  </div>
                  <p className="text-3xl font-bold mb-2">{metric.value}</p>
                  <div className="flex items-center gap-1">
                    {metric.isPositive ? (
                      <TrendingUp className="h-4 w-4 text-success" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-destructive" />
                    )}
                    <span
                      className={`text-sm font-medium ${
                        metric.isPositive ? "text-success" : "text-destructive"
                      }`}
                    >
                      {metric.change}
                    </span>
                    <span className="text-sm text-muted-foreground">vs mês anterior</span>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Revenue Chart */}
          <Card className="bg-card border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-semibold mb-1">Receita e Lucro</h3>
                <p className="text-sm text-muted-foreground">
                  Análise financeira dos últimos 8 meses
                </p>
              </div>
              <Badge className="bg-primary/20 text-primary border-primary/30">
                <TrendingUp className="mr-1 h-3 w-3" />
                Crescimento Positivo
              </Badge>
            </div>
            <ResponsiveContainer width="100%" height={350}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FACC15" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FACC15" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22C55E" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                <YAxis stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#FACC15"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                  name="Receita"
                />
                <Area
                  type="monotone"
                  dataKey="profit"
                  stroke="#22C55E"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorProfit)"
                  name="Lucro"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Growth */}
            <Card className="bg-card border-border p-6">
              <h3 className="text-xl font-semibold mb-1">Crescimento de Usuários</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Evolução de alunos e personais
              </p>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={userGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                  <YAxis stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1E1E1E",
                      border: "1px solid #333",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="students" fill="#FACC15" name="Alunos" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="trainers" fill="#22C55E" name="Personais" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Subscription Distribution */}
            <Card className="bg-card border-border p-6">
              <h3 className="text-xl font-semibold mb-1">Distribuição de Planos</h3>
              <p className="text-sm text-muted-foreground mb-6">Assinaturas ativas por tipo</p>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={subscriptionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {subscriptionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex justify-center gap-6 mt-4">
                {subscriptionData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {item.name}: {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Workout Completion */}
          <Card className="bg-card border-border p-6">
            <h3 className="text-xl font-semibold mb-1">Taxa de Conclusão de Treinos</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Comparativo de treinos completados vs planejados (última semana)
            </p>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={workoutCompletionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="day" stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                <YAxis stroke="#A1A1AA" style={{ fontSize: "12px" }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1E1E1E",
                    border: "1px solid #333",
                    borderRadius: "8px",
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="completed"
                  stroke="#FACC15"
                  strokeWidth={3}
                  name="Completados"
                  dot={{ r: 5 }}
                />
                <Line
                  type="monotone"
                  dataKey="planned"
                  stroke="#A1A1AA"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Planejados"
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Key Insights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-primary/20 to-transparent border-primary/30 p-6">
              <Activity className="h-8 w-8 text-primary mb-3" />
              <h4 className="font-semibold mb-2">Engajamento Alto</h4>
              <p className="text-sm text-muted-foreground">
                89% dos usuários completam pelo menos 3 treinos por semana
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-success/20 to-transparent border-success/30 p-6">
              <TrendingUp className="h-8 w-8 text-success mb-3" />
              <h4 className="font-semibold mb-2">Crescimento Acelerado</h4>
              <p className="text-sm text-muted-foreground">
                +127 novos usuários nos últimos 30 dias
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500/20 to-transparent border-blue-500/30 p-6">
              <Target className="h-8 w-8 text-blue-500 mb-3" />
              <h4 className="font-semibold mb-2">Retenção Excelente</h4>
              <p className="text-sm text-muted-foreground">
                94.3% dos usuários renovam suas assinaturas
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
