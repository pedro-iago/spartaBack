import { useState } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import {
  Dumbbell,
  PlayCircle,
  Calendar,
  CheckCircle,
  Clock,
  Home,
  User,
  ChefHat,
  TrendingUp,
  Target,
  ArrowLeft,
} from "lucide-react";
import { useNavigate } from "react-router";

interface Workout {
  id: string;
  name: string;
  type: string;
  duration: string;
  exercises: number;
  lastCompleted?: string;
  status: "active" | "completed" | "upcoming";
  difficulty: "beginner" | "intermediate" | "advanced";
}

export function StudentWorkouts() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("current");

  const currentWorkouts: Workout[] = [
    {
      id: "1",
      name: "Hypertrophy Push A",
      type: "Peito, Ombros, Tríceps",
      duration: "60 min",
      exercises: 8,
      status: "active",
      difficulty: "intermediate",
      lastCompleted: "Hoje",
    },
    {
      id: "2",
      name: "Leg Day - Força",
      type: "Pernas e Glúteos",
      duration: "75 min",
      exercises: 10,
      status: "active",
      difficulty: "advanced",
      lastCompleted: "Ontem",
    },
    {
      id: "3",
      name: "Pull Workout",
      type: "Costas e Bíceps",
      duration: "60 min",
      exercises: 7,
      status: "active",
      difficulty: "intermediate",
    },
  ];

  const completedWorkouts: Workout[] = [
    {
      id: "4",
      name: "Hypertrophy Push A",
      type: "Peito, Ombros, Tríceps",
      duration: "58 min",
      exercises: 8,
      status: "completed",
      difficulty: "intermediate",
      lastCompleted: "05/02/2026 - 18:30",
    },
    {
      id: "5",
      name: "Leg Day - Força",
      type: "Pernas e Glúteos",
      duration: "72 min",
      exercises: 10,
      status: "completed",
      difficulty: "advanced",
      lastCompleted: "04/02/2026 - 19:00",
    },
    {
      id: "6",
      name: "Pull Workout",
      type: "Costas e Bíceps",
      duration: "55 min",
      exercises: 7,
      status: "completed",
      difficulty: "intermediate",
      lastCompleted: "03/02/2026 - 18:00",
    },
    {
      id: "7",
      name: "Hypertrophy Push A",
      type: "Peito, Ombros, Tríceps",
      duration: "60 min",
      exercises: 8,
      status: "completed",
      difficulty: "intermediate",
      lastCompleted: "02/02/2026 - 18:45",
    },
  ];

  const getDifficultyBadge = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return <Badge className="bg-green-500/20 text-green-500 border-green-500/30">Iniciante</Badge>;
      case "intermediate":
        return <Badge className="bg-primary/20 text-primary border-primary/30">Intermediário</Badge>;
      case "advanced":
        return <Badge className="bg-red-500/20 text-red-500 border-red-500/30">Avançado</Badge>;
      default:
        return null;
    }
  };

  const WorkoutCard = ({ workout }: { workout: Workout }) => (
    <Card className="bg-card border-border hover:border-primary/50 transition-colors">
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-1">{workout.name}</h3>
            <p className="text-sm text-muted-foreground mb-2">{workout.type}</p>
            {getDifficultyBadge(workout.difficulty)}
          </div>
          {workout.status === "completed" && (
            <CheckCircle className="h-6 w-6 text-success" />
          )}
        </div>

        <div className="flex gap-4 mb-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{workout.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Target className="h-4 w-4" />
            <span>{workout.exercises} exercícios</span>
          </div>
        </div>

        {workout.lastCompleted && (
          <p className="text-xs text-muted-foreground mb-4">
            {workout.status === "completed" 
              ? `Completado: ${workout.lastCompleted}` 
              : `Último treino: ${workout.lastCompleted}`}
          </p>
        )}

        {workout.status === "active" ? (
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 border-primary/30 hover:bg-primary/10"
            >
              Ver Detalhes
            </Button>
            <Button
              className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={() => navigate("/student/workout")}
            >
              <PlayCircle className="mr-2 h-4 w-4" />
              Iniciar
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            className="w-full border-border hover:bg-muted"
          >
            Ver Histórico
          </Button>
        )}
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b border-border p-6">
        <Button
          variant="ghost"
          size="icon"
          className="mb-4"
          onClick={() => navigate("/student")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-primary/20 p-3 rounded-full">
            <Dumbbell className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl">Meus Treinos</h1>
            <p className="text-sm text-muted-foreground">Acompanhe seu progresso</p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-muted/50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-primary">{currentWorkouts.length}</p>
            <p className="text-xs text-muted-foreground">Ativos</p>
          </div>
          <div className="bg-muted/50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-success">{completedWorkouts.length}</p>
            <p className="text-xs text-muted-foreground">Completos</p>
          </div>
          <div className="bg-muted/50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold">42</p>
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full bg-muted h-12 mb-6">
            <TabsTrigger value="current" className="flex-1">
              <Calendar className="mr-2 h-4 w-4" />
              Atuais
            </TabsTrigger>
            <TabsTrigger value="completed" className="flex-1">
              <CheckCircle className="mr-2 h-4 w-4" />
              Histórico
            </TabsTrigger>
          </TabsList>

          <TabsContent value="current" className="space-y-4">
            {currentWorkouts.length > 0 ? (
              currentWorkouts.map((workout) => (
                <WorkoutCard key={workout.id} workout={workout} />
              ))
            ) : (
              <Card className="bg-card border-border p-8 text-center">
                <Dumbbell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum treino ativo</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Seu personal ainda não criou treinos para você
                </p>
                <Button variant="outline">Solicitar Treino</Button>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {completedWorkouts.length > 0 ? (
              completedWorkouts.map((workout) => (
                <WorkoutCard key={workout.id} workout={workout} />
              ))
            ) : (
              <Card className="bg-card border-border p-8 text-center">
                <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum treino completo</h3>
                <p className="text-sm text-muted-foreground">
                  Complete seu primeiro treino para vê-lo aqui
                </p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Progress Card */}
      <div className="px-4 pb-6">
        <Card className="bg-gradient-to-br from-primary/20 to-transparent border-primary/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="h-6 w-6 text-primary" />
            <h3 className="text-lg font-semibold">Seu Progresso</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Esta semana</span>
              <span className="font-semibold">5/6 treinos</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Este mês</span>
              <span className="font-semibold">18/24 treinos</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Sequência atual</span>
              <span className="font-semibold text-primary">7 dias 🔥</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="flex justify-around items-center h-16 max-w-md mx-auto px-4">
          <Button
            variant="ghost"
            size="icon"
            className="flex-col h-auto gap-1"
            onClick={() => navigate("/student")}
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">Início</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex-col h-auto gap-1 text-primary">
            <Dumbbell className="h-5 w-5 text-primary" />
            <span className="text-xs text-primary">Treinos</span>
          </Button>
          <Button variant="ghost" size="icon" className="flex-col h-auto gap-1">
            <ChefHat className="h-5 w-5" />
            <span className="text-xs">Dieta</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="flex-col h-auto gap-1"
            onClick={() => navigate("/student/profile")}
          >
            <User className="h-5 w-5" />
            <span className="text-xs">Perfil</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
