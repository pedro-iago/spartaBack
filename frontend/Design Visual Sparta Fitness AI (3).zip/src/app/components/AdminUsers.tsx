import { useState } from "react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Badge } from "@/app/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/app/components/ui/dialog";
import {
  Users,
  Search,
  UserPlus,
  UserCheck,
  Ban,
  Edit,
  Trash2,
  LogOut,
  LayoutDashboard,
  Settings,
  BarChart3,
  Filter,
  Download,
  MoreVertical,
} from "lucide-react";
import { useNavigate } from "react-router";

interface User {
  id: string;
  name: string;
  email: string;
  type: "student" | "trainer" | "admin";
  status: "active" | "inactive" | "suspended";
  joinedAt: string;
  lastAccess: string;
  subscription?: string;
}

export function AdminUsers() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const users: User[] = [
    {
      id: "1",
      name: "Carlos Silva",
      email: "carlos@email.com",
      type: "student",
      status: "active",
      joinedAt: "2026-01-28",
      lastAccess: "2 horas atrás",
      subscription: "Premium",
    },
    {
      id: "2",
      name: "Ana Santos",
      email: "ana@email.com",
      type: "trainer",
      status: "active",
      joinedAt: "2026-01-27",
      lastAccess: "1 hora atrás",
      subscription: "Pro",
    },
    {
      id: "3",
      name: "João Pedro",
      email: "joao@email.com",
      type: "student",
      status: "active",
      joinedAt: "2026-01-26",
      lastAccess: "5 horas atrás",
      subscription: "Basic",
    },
    {
      id: "4",
      name: "Marina Costa",
      email: "marina@email.com",
      type: "student",
      status: "inactive",
      joinedAt: "2026-01-25",
      lastAccess: "3 dias atrás",
      subscription: "Basic",
    },
    {
      id: "5",
      name: "Rafael Oliveira",
      email: "rafael@email.com",
      type: "trainer",
      status: "active",
      joinedAt: "2026-01-24",
      lastAccess: "30 min atrás",
      subscription: "Pro",
    },
    {
      id: "6",
      name: "Julia Almeida",
      email: "julia@email.com",
      type: "student",
      status: "active",
      joinedAt: "2026-01-23",
      lastAccess: "1 dia atrás",
      subscription: "Premium",
    },
    {
      id: "7",
      name: "Pedro Santos",
      email: "pedro@email.com",
      type: "admin",
      status: "active",
      joinedAt: "2025-12-01",
      lastAccess: "Agora",
      subscription: "Admin",
    },
    {
      id: "8",
      name: "Lucas Ferreira",
      email: "lucas@email.com",
      type: "student",
      status: "suspended",
      joinedAt: "2026-01-20",
      lastAccess: "5 dias atrás",
      subscription: "Basic",
    },
  ];

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" || user.type === typeFilter;
    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const stats = {
    total: users.length,
    students: users.filter((u) => u.type === "student").length,
    trainers: users.filter((u) => u.type === "trainer").length,
    admins: users.filter((u) => u.type === "admin").length,
    active: users.filter((u) => u.status === "active").length,
    inactive: users.filter((u) => u.status === "inactive").length,
    suspended: users.filter((u) => u.status === "suspended").length,
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "student":
        return (
          <Badge variant="secondary" className="bg-muted text-muted-foreground">
            Aluno
          </Badge>
        );
      case "trainer":
        return (
          <Badge className="bg-primary/20 text-primary border-primary/30">Personal</Badge>
        );
      case "admin":
        return (
          <Badge className="bg-purple-500/20 text-purple-500 border-purple-500/30">
            Admin
          </Badge>
        );
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-success/20 text-success border-success/30">Ativo</Badge>
        );
      case "inactive":
        return (
          <Badge variant="secondary" className="bg-muted text-muted-foreground">
            Inativo
          </Badge>
        );
      case "suspended":
        return (
          <Badge className="bg-destructive/20 text-destructive border-destructive/30">
            Suspenso
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-sidebar border-r border-sidebar-border p-6 hidden lg:block">
        <div className="mb-8">
          <h1 className="text-2xl mb-1 text-primary">SPARTA AI</h1>
          <p className="text-sm text-muted-foreground">Admin Panel</p>
        </div>

        <nav className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate("/admin")}
          >
            <LayoutDashboard className="mr-3 h-5 w-5" />
            Dashboard
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start bg-primary/10 text-primary hover:bg-primary/20"
          >
            <Users className="mr-3 h-5 w-5" />
            Usuários
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate("/admin/reports")}
          >
            <BarChart3 className="mr-3 h-5 w-5" />
            Relatórios
          </Button>
          <Button variant="ghost" className="w-full justify-start">
            <Settings className="mr-3 h-5 w-5" />
            Configurações
          </Button>
        </nav>

        <div className="absolute bottom-6 left-6 right-6">
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground"
            onClick={() => navigate("/")}
          >
            <LogOut className="mr-3 h-5 w-5" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">
        {/* Header */}
        <div className="bg-card border-b border-border p-6">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl mb-2">Gerenciar Usuários</h1>
            <p className="text-muted-foreground">
              Visualize e gerencie todos os usuários da plataforma
            </p>
          </div>
        </div>

        <div className="p-6 max-w-7xl mx-auto space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            <Card className="bg-gradient-to-br from-primary/20 to-transparent border-primary/30 p-4">
              <p className="text-sm text-muted-foreground mb-1">Total</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Alunos</p>
              <p className="text-2xl font-bold">{stats.students}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Personais</p>
              <p className="text-2xl font-bold">{stats.trainers}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Admins</p>
              <p className="text-2xl font-bold">{stats.admins}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Ativos</p>
              <p className="text-2xl font-bold text-success">{stats.active}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Inativos</p>
              <p className="text-2xl font-bold">{stats.inactive}</p>
            </Card>
            <Card className="bg-card border-border p-4">
              <p className="text-sm text-muted-foreground mb-1">Suspensos</p>
              <p className="text-2xl font-bold text-destructive">{stats.suspended}</p>
            </Card>
          </div>

          {/* Filters and Actions */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-muted border-border"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-[150px] bg-muted border-border">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="student">Alunos</SelectItem>
                <SelectItem value="trainer">Personais</SelectItem>
                <SelectItem value="admin">Admins</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[150px] bg-muted border-border">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Ativos</SelectItem>
                <SelectItem value="inactive">Inativos</SelectItem>
                <SelectItem value="suspended">Suspensos</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <UserPlus className="mr-2 h-4 w-4" />
              Novo Usuário
            </Button>
            <Button variant="outline" className="border-border">
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>

          {/* Users Table */}
          <Card className="bg-card border-border">
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50 hover:bg-muted/50">
                    <TableHead>Usuário</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Data Cadastro</TableHead>
                    <TableHead>Último Acesso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell className="text-muted-foreground">{user.email}</TableCell>
                      <TableCell>{getTypeBadge(user.type)}</TableCell>
                      <TableCell>{getStatusBadge(user.status)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {user.subscription}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(user.joinedAt).toLocaleDateString("pt-BR")}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {user.lastAccess}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 hover:bg-muted"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 hover:bg-muted"
                          >
                            {user.status === "active" ? (
                              <Ban className="h-4 w-4 text-destructive" />
                            ) : (
                              <UserCheck className="h-4 w-4 text-success" />
                            )}
                          </Button>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 hover:bg-destructive/10 hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-card border-border">
                              <DialogHeader>
                                <DialogTitle>Confirmar exclusão</DialogTitle>
                                <DialogDescription>
                                  Tem certeza que deseja excluir o usuário {user.name}? Esta
                                  ação não pode ser desfeita.
                                </DialogDescription>
                              </DialogHeader>
                              <div className="flex gap-2 justify-end">
                                <Button variant="outline">Cancelar</Button>
                                <Button className="bg-destructive hover:bg-destructive/90 text-white">
                                  Excluir
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>

          {/* Empty State */}
          {filteredUsers.length === 0 && (
            <Card className="bg-card border-border p-12 text-center">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Nenhum usuário encontrado</h3>
              <p className="text-muted-foreground">
                Tente ajustar os filtros de busca
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
